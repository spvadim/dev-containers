*****************************
zope.component Package Readme
*****************************

*This package is intended to be independently reusable in any Python
project. It is maintained by the* `Zope Toolkit project <http://docs.zope.org/zopetoolkit/>`_.

This package represents the core of the Zope Component Architecture.
Together with the 'zope.interface' package, it provides facilities for
defining, registering and looking up components.

.. contents::
