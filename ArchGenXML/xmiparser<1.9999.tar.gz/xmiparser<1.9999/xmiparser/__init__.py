import xmiparser
from xmiparser import parse