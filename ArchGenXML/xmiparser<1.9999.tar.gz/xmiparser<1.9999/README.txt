An API for files in the XML format `XMI`_ defined by `OMG`_ to store UML.

This is the standalone version of the xmiparser. It was formerly part of 
the `ArchGenXML`_ code generator.

.. _XMI: http://www.omg.org/docs/formal/03-05-02.pdf
.. _OMG: http://www.omg.org
.. _ArchGenXML: http://plone.org/products/ArchGenXML

.. contents::
