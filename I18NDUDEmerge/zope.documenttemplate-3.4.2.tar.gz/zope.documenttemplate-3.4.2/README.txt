===================================
Document Templating Markup Language
===================================

This package implements the Document Templating Markup Language (DTML). It
uses custom SGML tags to implement simple programmatic feratures, such as
variable replacement, conditional logic and loops.


DTML was the first templating language developed for Zope 2 and is still
preferred by some over newer templating solutions due to its speed and
simplicity.

