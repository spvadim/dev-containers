from zope.interface import Interface

class IPackage(Interface):
    """Package UML Element containing classes."""