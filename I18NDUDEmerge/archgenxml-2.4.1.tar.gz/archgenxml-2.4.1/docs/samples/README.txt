Not all the samples might be working, they'll have to be checked later
on.

I *do* know that the argouml sample 'plonehrm.zargo' works. It
contains normal contenttypes, a doctest, a portal_tool and some
workflows. Ought to be a nice example.

