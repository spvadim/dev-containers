Directory with tests for archgenxml, started 2005-04-09.

At the moment there's only one testfile, you can run it from
archgenxml's 'src/archgenxml' directory:

'python tests/testPyParser.py'

