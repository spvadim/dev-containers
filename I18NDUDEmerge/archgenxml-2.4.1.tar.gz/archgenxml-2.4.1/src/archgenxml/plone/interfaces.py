from zope.interface import Interface

class IConfigPyView(Interface):
    pass
