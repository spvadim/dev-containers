# Import the modules as they contain instructions for the zope3
# component architecture (adapter declarations and so).
import config_py


